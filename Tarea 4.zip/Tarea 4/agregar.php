<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

include("db.php");

if (!empty($_POST['titulo']) && !empty($_POST['id_usuario'])) {
    $titulo = $conexion->real_escape_string($_POST['titulo']);
    $id_usuario = intval($_POST['id_usuario']);
    
    // El usuario normal solo puede agregar tareas para sí mismo
    if ($_SESSION['rol'] == 'usuario' && $id_usuario != $_SESSION['id']) {
        die("No tienes permiso para agregar tareas a otros usuarios.");
    }
    
    $checkUser = $conexion->query("SELECT id FROM usuarios WHERE id = $id_usuario");
    if ($checkUser->num_rows > 0) {
        $conexion->query("INSERT INTO tareas (titulo, id_usuario) VALUES ('$titulo', $id_usuario)");
    } else {
        die("Usuario inválido.");
    }
}

header("Location: index.php");
