<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

include("db.php");

$usuario_id = $_SESSION['id'];
$rol = $_SESSION['rol'];

// Obtener tareas (mostrar todas para admin, solo propias para usuario estandar)
if ($rol == 'admin') {
    $tareas = $conexion->query("SELECT tareas.*, usuarios.nombre_usuario FROM tareas 
        JOIN usuarios ON tareas.id_usuario = usuarios.id");
} else {
    $tareas = $conexion->query("SELECT tareas.*, usuarios.nombre_usuario FROM tareas 
        JOIN usuarios ON tareas.id_usuario = usuarios.id WHERE tareas.id_usuario = $usuario_id");
}

// Obtener lista de usuarios para asignar tareas (admin ve todos, usuario solo a sí mismo)
if ($rol == 'admin') {
    $usuarios = $conexion->query("SELECT id, nombre_usuario FROM usuarios");
} else {
    $usuarios = $conexion->query("SELECT id, nombre_usuario FROM usuarios WHERE id = $usuario_id");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Tareas</title>
    <style>
        body { font-family: Arial; background: #f0f0f0; padding: 20px; }
        .tarea { background: white; padding: 10px; margin-bottom: 10px; border-radius: 5px; }
        .completada { text-decoration: line-through; color: green; }
        .btn { cursor: pointer; padding: 3px 7px; margin-left: 5px; }
    </style>
</head>
<body>

<h2>Bienvenido <?= htmlspecialchars($_SESSION['usuario']) ?> (Rol: <?= htmlspecialchars($rol) ?>)</h2>
<a href="logout.php">Cerrar sesión</a>

<h3>Agregar tarea</h3>
<form action="agregar.php" method="POST">
    <input type="text" name="titulo" required placeholder="Nueva tarea">
    <select name="id_usuario" required>
        <?php while ($user = $usuarios->fetch_assoc()): ?>
            <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['nombre_usuario']) ?></option>
        <?php endwhile; ?>
    </select>
    <button type="submit">Agregar</button>
</form>

<hr>

<h3>Tareas</h3>

<?php while ($tarea = $tareas->fetch_assoc()): ?>
    <div class="tarea <?= $tarea['completada'] ? 'completada' : '' ?>">
        <?= htmlspecialchars($tarea['titulo']) ?> 
        <small>(por <?= htmlspecialchars($tarea['nombre_usuario']) ?>)</small>

        <form style="display:inline;" action="completar.php" method="POST">
            <input type="hidden" name="id" value="<?= $tarea['id'] ?>">
            <button class="btn" type="submit">✔</button>
        </form>

        <?php if ($rol == 'admin'): ?>
            <form style="display:inline;" action="eliminar.php" method="POST">
                <input type="hidden" name="id" value="<?= $tarea['id'] ?>">
                <button class="btn" type="submit">🗑️</button>
            </form>
        <?php endif; ?>
    </div>
<?php endwhile; ?>

</body>
</html>
