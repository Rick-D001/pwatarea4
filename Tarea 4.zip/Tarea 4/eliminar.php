<?php
session_start();
if (!isset($_SESSION['id']) || $_SESSION['rol'] != 'admin') {
    die("No tienes permiso para eliminar tareas.");
}

include("db.php");

if (isset($_POST['id'])) {
    $id = intval($_POST['id']);
    $conexion->query("DELETE FROM tareas WHERE id = $id");
}

header("Location: index.php");
