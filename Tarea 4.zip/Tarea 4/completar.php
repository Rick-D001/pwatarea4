<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

include("db.php");

if (isset($_POST['id'])) {
    $id = intval($_POST['id']);
    $usuario_id = $_SESSION['id'];
    $rol = $_SESSION['rol'];

    // Verificar si puede completar la tarea (admin puede cualquier tarea, usuario solo propia)
    if ($rol == 'admin') {
        $conexion->query("UPDATE tareas SET completada = NOT completada WHERE id = $id");
    } else {
        $conexion->query("UPDATE tareas SET completada = NOT completada WHERE id = $id AND id_usuario = $usuario_id");
    }
}

header("Location: index.php");
